DYADIC-LEVEL INTERNATIONAL CRISIS DATA (version 2.0)

J. Joseph Hewitt
International Crisis Behavior Project

July 9, 2003
--------------------------------------


CONTENTS OF icbdy_20.zip

 * codebook.rtf - Complete codebook for the dyadic-level crisis data
 * icbdy_20.dat - Dyadic-level crisis data, tab-delimited
 * icbdy_20.sav - Dyadic-level crisis data, SPSS for Windows
 * readme.txt - this readme file
 * version_20_revisions.rtf - Description of changes made since version 1.0.

NOTE: An additional document that provides a descriptive summary of coding decisions
for each crisis is available from the author.  For a copy, please contact Joseph
Hewitt at hewittjj@missouri.edu. 